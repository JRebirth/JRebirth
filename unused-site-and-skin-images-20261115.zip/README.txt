﻿JRebirth unused site/skin images archive — 20261115
Created because these assets are no longer referenced by the modern Maven site chrome (landing.css / site-docs.css).

KEPT in site brand/: hero-flight-high.webp, hero-flight-4k.webp, logo-phoenix-rise.webp, logo-header.png, logo-lockup.png
KEPT in skin images/: JRebirth_Title.png, JRebirth_Logo_80px.png, lightbox/{close,loading,prev,next}

SITE files archived:
  \doc\uml\BasicCommand.png
  \doc\uml\Component.png
  \doc\uml\GestureHandler.png
  \doc\uml\Handler.png
  \doc\uml\Model.png
  \images\arch\wb-pyramid.svg
  \images\brand\hero-banner-concept.png
  \images\brand\hero-desktop-ai.png
  \images\brand\hero-phoenix-full-alpha.png
  \images\brand\hero-phoenix-full.png
  \images\brand\hero-phoenix-kit-alpha.png
  \images\brand\hero-phoenix-mobile-alpha.png
  \images\brand\hero-phoenix-mobile.png
  \images\brand\hero-phoenix.png
  \images\brand\logo-header-96.png
  \images\brand\logo-lockup-ai.png
  \images\brand\logo-lockup-kit.png
  \images\brand\logo-main.png
  \images\brand\logo-mark-ai.png
  \images\brand\logo-mark-alpha.png
  \images\brand\logo-mark.png
  \images\brand\logo-official.jpg
  \images\brand\mobile-mockup-ref.png
  \images\brand\archive\hero-desktop-ai.png
  \images\brand\archive\hero-desktop.png
  \images\brand\archive\hero-flight-4k.jpg
  \images\brand\archive\hero-flight-high.jpg
  \images\brand\archive\hero-mobile.png
  \images\brand\archive\README.md

SKIN files archived:
  \images\apache-maven-project-2.png
  \images\back_top.png
  \images\bar_above_catcher.png
  \images\bar_below_catcher.png
  \images\bullet_list.png
  \images\catcher_back.png
  \images\done.png
  \images\header_back.png
  \images\JRebirthApplicationFramework.png
  \images\JRebirth_32x32.png
  \images\next.png
  \images\previous.png
  \images\quote-droite.png
  \images\quote-gauche.png
  \images\titre.png
  \images\_barre_under_bloc_slogan.png
  \images\_barre_under_boutons.png
  \images\lightbox\bg-checker.png
  \images\lightbox\box.png
  \images\lightbox\bullet.gif
  \images\lightbox\favicon.gif
  \images\lightbox\speech-bubbles.png
  \images\navmenu\current-bg.gif
  \images\navmenu\hover-bg.gif
  \images\navmenu\menu-bg.gif
